import { ResultTable } from '@/components/ResultTable'
import React from 'react'

const PreguntasPage = () => {
  return (
    <ResultTable/>
  )
}

export default PreguntasPage